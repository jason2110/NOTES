from tkinter import*
from tkinter import ttk
import tkinter as tk
import tempfile
import os

import tkinter.messagebox



class POS:

    def __init__(self,root):
        self.root =root
        self.root.title("Point of Sale")
        self.root.geometry("1350x750+0+0")
        self.root.configure(background='cadetblue')
        self.input_value = True
        
        self.Coffee1= PhotoImage(file = "coffee1.gif")
        self.Coffee2= PhotoImage(file = "coffee2.gif")
        self.Coffee3= PhotoImage(file = "coffee3.gif")
        self.Coffee4= PhotoImage(file = "coffee4.gif") 
        self.Coffee5= PhotoImage(file = "RawCoffee.gif")
        self.Coffee6= PhotoImage(file = "CrazyCoffee.gif")

        self.Drink1= PhotoImage(file = "SummerSoftDrinks.gif")
        self.Drink2= PhotoImage(file = "cokeA.gif")
        self.Drink3= PhotoImage(file = "coke.gif")
        self.Drink4= PhotoImage(file = "Non_Alcoholic.gif") 
        self.Drink5= PhotoImage(file = "Cocktails.gif")
        self.Drink6= PhotoImage(file = "Just Drinks.gif")

        self.Cake1= PhotoImage(file = "AngleCake.gif")
        self.Cake2= PhotoImage(file = "Easy Cake.gif")
        self.Cake3= PhotoImage(file = "HomemadeCake.gif")
        self.Cake4= PhotoImage(file = "cake1.gif")
        self.Cake5= PhotoImage(file = "Black Forest Cake.gif")
        self.Cake6= PhotoImage(file = "cake2.gif")

        self.IceCake1= PhotoImage(file = "Vanilla Cake.gif")
        self.IceCake2= PhotoImage(file = "cake3.gif")
        self.IceCake3= PhotoImage(file = "IceCreamCake.gif")
        self.IceCake4= PhotoImage(file = "UltimateCake.gif")
        self.IceCake5= PhotoImage(file = "RainCake.gif")
        self.IceCake6= PhotoImage(file = "PinkCake.gif")        


        global operator
        operator=""
        cal = StringVar()
        Change_Input = StringVar()
        Cash_Input = StringVar()
        Tax_Input = StringVar()
        SubTotal_Input = StringVar()
        Total_Input = StringVar()
        Item = StringVar()
        Qty = StringVar()
        Amount = StringVar()
        choice = StringVar()
        Cash_Input = StringVar()
        #operator=''


        def btnClearDisplay():
            global operator
            operator=""
            Change_Input.set("")
            Cash_Input.set("0")
            Tax_Input.set("")
            SubTotal_Input.set("")
            Total_Input.set("")
            for i in self.POS_records.get_children():
                self.POS_records.delete(i)

        def delete():
            ItemCost=0.0
            Tax = 2.5
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
            SubTotal_Input.set(str('£%.2f'%(ItemCost)))
            Tax_Input.set(str('£%.2f'%((ItemCost * Tax)/100)))
            Total_Input.set(str('£%.2f'%((ItemCost) + ((ItemCost * Tax)/100))))
            selected_item = (self.POS_records.selection()[0])
            self.POS_records.delete(selected_item)
            giveChange()
            

        def giveChange():
            ItemCost=0.0
            Tax = 2.5            
            CashInput = float(Cash_Input.get())
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
            Change_Input.set(str('£%.2f'%(CashInput-((ItemCost) + ((ItemCost * Tax)/100)))))
            if (Cash_Input.get() == "0"):
                Change_Input.set("")
                Method_of_Pay()

        def ring():
            root.bell()

        def iPrint1():
            select = self.POS_records.focus()
            q = str(self.POS_records.item(select, 'values'))      
            filename = tempfile.mktemp(".txt")
            open (filename, "w"). write(q)
            os.startfile(filename, "print")
            ring()

        def iPrint():
            q = self.txtReceipt.get("1.0", "end-1c")
            print(q)
            filename = tempfile.mktemp(".txt")
            open (filename, "w"). write(q)
            os.startfile(filename, "print")

        def iPrints():
            #for child in self.POS_records.get_children():
                #q=(self.POS_records.item(child)["values"])
            select = self.POS_records.focus() #get_children()#("1.0", "end-1c")
            q = str(self.POS_records.item(select, 'values'))
            print(q)            
            filename = tempfile.mktemp(".txt")
            open (filename, "w"). write(q)
            os.startfile(filename, "print")
            

        def iExit():
            iExit= tkinter.messagebox.askyesno("Point of Sale","Do you want to quit?")
            if iExit > 0:
                root.destroy()
                return

        def Method_of_Pay():
            if (choice.get() == "Cash"):
                self.txtCost.focus()
                Cash_Input.set("")
            elif (choice.get()==""):
                Cash_Input.set("0")
                Change_Input.set("")
             


        #===================================================================================================
        MainFrame =Frame(self.root,bg='cadetblue')
        MainFrame.grid(padx=8,pady=5)

        ButtonFrame =Frame(MainFrame, bd=5, width=1350, height=160, padx=4,pady=4, bg="cadet blue", relief=RIDGE)
        ButtonFrame.pack(side=BOTTOM)
        
        DataFrame =Frame(MainFrame, bd=5,padx=5, width=1300, height=400,bg='cadetblue',  relief=RIDGE)
        DataFrame.pack(side=BOTTOM)

        DataFrameLEFTCover =LabelFrame(DataFrame, bd=5, width=800, height=300, pady=2, relief=RIDGE
                            , bg='cadetblue', font=('arial', 12,'bold'), text="Point of Sale",)
        DataFrameLEFTCover.pack(side=LEFT)
        
        ChangeButtonFrame= Frame(DataFrameLEFTCover, bd=5, width=300, height=460, pady=5, relief=RIDGE)
        ChangeButtonFrame.pack(side=LEFT,padx=4)

        ReceiptFrame =Frame(DataFrameLEFTCover, bd=5, width=200, height=400, pady=5,padx=1, relief=RIDGE)                             
        ReceiptFrame .pack(side=RIGHT,padx=0)
        
        FoodItemFrame =LabelFrame(DataFrame, bd=5, width=450, height=300, padx=5, pady=2, relief=RIDGE
                                   ,bg='cadetblue', font=('arial', 12,'bold'), text="Items",)
        FoodItemFrame.pack(side=RIGHT)
        #========================================================================================================
        CalFrame =Frame(ButtonFrame,bd=5,width=432, height=140, relief=RIDGE)
        CalFrame.grid(row = 0, column = 0,padx=5)
        ChangeFrame =Frame(ButtonFrame,bd=5,width=500, height=140,pady=2, relief=RIDGE)
        ChangeFrame.grid(row = 0, column = 1,padx=5)
        RemoveFrame =Frame(ButtonFrame,bd=5,width=400, height=140, pady=4, relief=RIDGE)
        RemoveFrame.grid(row = 0, column = 2,padx=5)
        #===========================================CalculateFrame=Widget==============================================
        self.lblSubTotal = Label(CalFrame, font=('arial',14, 'bold'),text="Sub Total", bd=5, )
        self.lblSubTotal.grid(row=0,column=0, sticky =W, padx=5)
        self.txtSubTotal = Entry(CalFrame,font=('arial', 14,'bold'), bd=2, width=24,justify = 'left',
                                 textvariable=SubTotal_Input)
        self.txtSubTotal.grid(row=0,column=1)       

        self.lblTax = Label(CalFrame, font=('arial',14, 'bold'),text="Tax", bd=5 )
        self.lblTax .grid(row=1,column=0 , sticky =W, padx=5)
        self.txtTax  = Entry(CalFrame,font=('arial', 14,'bold'), bd=2, width=24, textvariable=Tax_Input)
        self.txtTax .grid(row=1,column=1, sticky =W)

        self.lblTotal = Label(CalFrame, font=('arial',14, 'bold'),text="Total", bd=5 )
        self.lblTotal.grid(row=2,column=0 , sticky =W, padx=5)
        self.txtTotal = Entry(CalFrame,font=('arial', 14,'bold'), bd=2, width=24, textvariable=Total_Input)
        self.txtTotal.grid(row=2,column=1, sticky =W)
        #=========================================ChangeFrame=Widget======================================================
        self.lblMoP = Label(ChangeFrame, font=('arial',14, 'bold'),text="Method of Payment", bd=2, )
        self.lblMoP.grid(row=0,column=0, sticky =W, padx=2)
        self.cboMoP=ttk.Combobox(ChangeFrame, width=36 , font=('arial',14,'bold'),state='readonly',
                                 textvariable=choice,justify=RIGHT)
        self.cboMoP['values'] =('','Cash','Visa Card','Master Card')
        self.cboMoP.current(0)
        self.cboMoP.grid(row=0,column=1)

        self.lblCost = Label(ChangeFrame, font=('arial',14, 'bold'),text="Cost", bd=5, )
        self.lblCost.grid(row=1,column=0, sticky =W, padx=2)
        self.txtCost = Entry(ChangeFrame,font=('arial', 14,'bold'), bd=2, width=38,textvariable=Cash_Input,justify=RIGHT)
        self.txtCost.grid(row=1,column=1)
        self.txtCost.insert(0, "0")

        self.lblChange = Label(ChangeFrame, font=('arial',14, 'bold'),text="Change", bd=5 )
        self.lblChange.grid(row=2,column=0 , sticky =W, padx=2)
        self.txtChange = Entry(ChangeFrame,font=('arial', 14,'bold'),bd=2, textvariable=Change_Input,width=38,justify=RIGHT)
        self.txtChange.grid(row=2,column=1, sticky =W)
        #==========================================RemoveFrame=====================================================
        self.btnPay=Button(RemoveFrame, padx=2, font=('arial',15, 'bold'),text="Pay", width =10, height=1,bd=2,
                           command=giveChange)
        self.btnPay.grid(row=0,column=0,padx=4,pady=2)
        
        self.btnPrint=Button(RemoveFrame, padx=2, font=('arial',15, 'bold'),text="Print", width =10, height=1,bd=2,
                             command = iPrint)
        self.btnPrint.grid(row=1,column=1,padx=2, pady=2)
        
        self.btnReset=Button(RemoveFrame, padx=2, font=('arial',15, 'bold'),text="Reset", width =10, height=1,bd=2,
                               command=btnClearDisplay)
        self.btnReset.grid(row=1,column=0,padx=2, pady=2)        

        self.btnRemoveItem=Button(RemoveFrame, padx=2, font=('arial',15, 'bold'),text="Remove Item", width =10,
                                  height=1,bd=2, command=delete)
        self.btnRemoveItem.grid(row=0,column=1,padx=2, pady=2)
        
        #=========================================================================================================

                
        def Coffee1():   
            ItemCost = 2.3 
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Coffee Capp", "1", "2.3"))
            self.txtReceipt.insert(END, ("Coffee Capp" + "\t\t\t" + "1" + "\t\t\t" + "2.3" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.3)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.3)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.3) + ((ItemCost-2.3)* Tax)/100))) 
                

        def Coffee2():  
            ItemCost = 1.9
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Cream Coffee", "1", "1.9"))
            self.txtReceipt.insert(END, ("Cream Coffee" + "\t\t\t" + "1" + "\t\t\t" + "1.9" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.9)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.9)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.9) + ((ItemCost-1.9)* Tax)/100))) 

        def Coffee3():   
            ItemCost = 1.70
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Black Coffee", "1", "1.70"))
            self.txtReceipt.insert(END, ("Black Coffee" + "\t\t\t" + "1" + "\t\t\t" + "1.70" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.7)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.7)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.7) + ((ItemCost-1.7)* Tax)/100))) 

        def Coffee4():  
            ItemCost = 0.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("India Coffee", "1", "0.90"))
            self.txtReceipt.insert(END, ("India Coffee" + "\t\t\t" + "1" + "\t\t\t" + "0.90" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2]) 
                SubTotal_Input.set(str('£%.2f'%(ItemCost-0.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-0.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-0.90) + ((ItemCost-0.90)* Tax)/100))) 

        def Coffee5():   
            ItemCost = 3.95
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Original Coffee", "1", "3.95"))
            self.txtReceipt.insert(END, ("Original Coffee" + "\t\t\t" + "1" + "\t\t\t" + "3.95" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-3.95)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-3.95)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-3.95) + ((ItemCost-3.95)* Tax)/100))) 

        def Coffee6():  
            ItemCost = 3.75
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Chocolate Latta", "1", "3.75"))
            self.txtReceipt.insert(END, ("Chocolate Latta" + "\t\t\t" + "1" + "\t\t\t" + "3.75" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-3.75)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-3.75)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-3.75) + ((ItemCost-3.75)* Tax)/100))) 
        #=========================================================================================================

        def Drink1():   
            ItemCost = 1.20
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Flavour", "1", "1.20"))
            self.txtReceipt.insert(END, ("Orange Flavour" + "\t\t\t" + "1" + "\t\t\t" + "1.20" + "\n"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.20)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.20)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.20) + ((ItemCost-1.20)* Tax)/100))) 

        def Drink2():  
            ItemCost = 1.10
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Juice", "1", "1.10"))
            self.txtReceipt.insert(END, ("Orange Juice" + "\t\t\t" + "1" + "\t\t\t" + "1.10" + "\n"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.10)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.10)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.10) + ((ItemCost-1.10)* Tax)/100))) 

        def Drink3():   
            ItemCost = 1.20
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Mixed Drink", "1", "1.20"))
            self.txtReceipt.insert(END, ("Mixed Drink" + "\t\t\t" + "1" + "\t\t\t" + "1.20" + "\n"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.20)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.20)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.20) + ((ItemCost-1.20)* Tax)/100))) 

        def Drink4():  
            ItemCost = 2.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Mixer", "1", "2.90"))
            self.txtReceipt.insert(END, ("Orange Mixer" + "\t\t\t" + "1" + "\t\t\t" + "2.90" + "\n"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.90) + ((ItemCost-2.90)* Tax)/100))) 

        def Drink5():   
            ItemCost = 3.20
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Tropicana Juice ", "1", "3.20"))
            self.txtReceipt.insert(END, ("Tropicana Juice" + "\t\t\t" + "1" + "\t\t\t" + "3.20" + "\n"))
                        
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-3.20)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-3.20)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-3.20) + ((ItemCost-3.20)* Tax)/100))) 

        def Drink6():  
            ItemCost = 1.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Tropicana", "1", "1.90"))
            self.txtReceipt.insert(END, ("Orange Tropicana" + "\t\t" + "1" + "\t\t\t" + "1.90" + "\n"))###########################################################
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.90) + ((ItemCost-1.90)* Tax)/100)))                
        #=========================================================================================================self.txtReceiptself.txtReceipt
        def Cake1():   
            ItemCost = 2.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Angle Cake", "1", "1.20"))
            self.txtReceipt.insert(END, ("Angle Cake" + "\t\t\t" + "1" + "\t\t\t" + "1.20" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.90) + ((ItemCost-2.90)* Tax)/100))) 

        def Cake2():  
            ItemCost = 2.20
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Easy Cake", "1", "2.20"))
            self.txtReceipt.insert(END, ("Easy Cake" + "\t\t\t" + "1" + "\t\t\t" + "2.20" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.20)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.20)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.20) + ((ItemCost-2.20)* Tax)/100))) 

        def Cake3():   
            ItemCost = 2.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Homemade Cake", "1", "2.90"))
            self.txtReceipt.insert(END, ("Homemade Cake" + "\t\t\t" + "1" + "\t\t\t" + "2.90" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.90) + ((ItemCost-2.90)* Tax)/100))) 

        def Cake4():  
            ItemCost = 2.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Mixer", "1", "2.90"))
            self.txtReceipt.insert(END, ("Orange Mixer" + "\t\t\t" + "1" + "\t\t\t" + "2.90" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.90) + ((ItemCost-2.90)* Tax)/100))) 

        def Cake5():   
            ItemCost = 3.20
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Juiceana", "1", "3.20"))
            self.txtReceipt.insert(END, ("Orange Juiceana" + "\t\t\t" + "1" + "\t\t\t" + "3.20" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-3.20)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-3.20)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-3.20) + ((ItemCost-3.20)* Tax)/100))) 

        def Cake6():  
            ItemCost = 1.90
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Orange Drink", "1", "1.90"))
            self.txtReceipt.insert(END, ("Tropicana Drink" + "\t\t\t" + "1" + "\t\t\t" + "1.90" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.90)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.90)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.90) + ((ItemCost-1.90)* Tax)/100))) 
        #=========================================================================================================
        def IceCake1():   
            ItemCost = 2.10
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Vanilla Cake", "1", "2.10"))
            self.txtReceipt.insert(END, ("Vanilla Cake" + "\t\t\t" + "1" + "\t\t\t" + "2.10" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.10)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.10)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.10) + ((ItemCost-2.10)* Tax)/100))) 

        def IceCake2():  
            ItemCost = 2.75
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Cup Cake", "1", "2.75"))
            self.txtReceipt.insert(END, ("Cup Cake" + "\t\t\t" + "1" + "\t\t\t" + "2.75" + "\n"))

            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.75)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.75)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.75) + ((ItemCost-2.75)* Tax)/100))) 

        def IceCake3():   
            ItemCost = 1.59
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("IceCream Cake", "1", "1.59"))
            self.txtReceipt.insert(END, ("IceCream Cake" + "\t\t\t" + "1" + "\t\t\t" + "1.59" + "\n"))

            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.59)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.59)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.59) + ((ItemCost-1.59)* Tax)/100))) 

        def IceCake4():  
            ItemCost = 2.99
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Ultimate Cake", "1", "2.99"))
            self.txtReceipt.insert(END, ("Ultimate Cake" + "\t\t\t" + "1" + "\t\t\t" + "2.99" + "\n"))            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.99)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.99)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.99) + ((ItemCost-2.99)* Tax)/100))) 

        def IceCake5():   
            ItemCost = 3.40
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Rainbow Cake", "1", "3.40"))
            self.txtReceipt.insert(END, ("Rainbow Cake" + "\t\t\t" + "1" + "\t\t\t" + "3.40" + "\n"))
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-3.40)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-3.40)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-3.40) + ((ItemCost-3.40)* Tax)/100))) 

        def IceCake6():  
            ItemCost = 2.89
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Pink Cake", "1", "2.89"))
            self.txtReceipt.insert(END, ("Pink Cake" + "\t\t\t" + "1" + "\t\t\t" + "2.89" + "\n"))            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.89)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.89)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.89) + ((ItemCost-2.89)* Tax)/100))) 
        #=========================================================================================================
                
        def EatFedBurger():  
            ItemCost = 1.99
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Fed Burger", "1", "1.99"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.99)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.99)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.99) + ((ItemCost-1.99)* Tax)/100)))

        def EatFries():  
            ItemCost = 1.25
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Fries", "1", "1.25"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.25)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.25)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.25) + ((ItemCost-1.25)* Tax)/100)))

        def EatFishBurger():  
            ItemCost = 2.35
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Fish Burger", "1", "2.35"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.35)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.35)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.35) + ((ItemCost-2.35)* Tax)/100)))

        def EatBreadRoll():  
            ItemCost = 1.25
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Bread Roll", "1", "1.25"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-1.25)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-1.25)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-1.25) + ((ItemCost-1.25)* Tax)/100))) 

        def EatChickenNuggets():  
            ItemCost = 2.55
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Chicken Nuggets", "1", "2.55"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.55)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.55)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.55) + ((ItemCost-2.55)* Tax)/100)))

        def EatMeatPie():  
            ItemCost = 2.45
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Nigerian MeatPie", "1", "2.45"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.45)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.45)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.45) + ((ItemCost-2.45)* Tax)/100)))

        def EatHotdog():  
            ItemCost = 2.50
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Hot dog", "1", "2.50"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-2.50)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-2.50)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-2.50) + ((ItemCost-2.50)* Tax)/100)))

        def EatMeatballs():  
            ItemCost = 3.45
            Tax = 2.5
            self.POS_records.insert("", tk.END, values=("Meat balls", "1", "3.45"))
            
            for child in self.POS_records.get_children():
                ItemCost += float(self.POS_records.item(child, "values")[2])
                SubTotal_Input.set(str('£%.2f'%(ItemCost-3.45)))
                Tax_Input.set(str('£%.2f'%(((ItemCost-3.45)* Tax)/100))) 
                Total_Input.set(str('£%.2f'%((ItemCost-3.45) + ((ItemCost-3.45)* Tax)/100)))

        def btnClick(numbers):
            global operator
            operator=operator + str(numbers)
            Cash_Input.set(operator)



        #====================================================Treeview==FrameDetail=============================

        scroll_y=Scrollbar(ReceiptFrame ,orient=VERTICAL)
        self.POS_records=ttk.Treeview(ReceiptFrame ,height=20,columns=("Item","Qty","Amount"),yscrollcommand=scroll_y.set)

        scroll_y.pack(side=RIGHT, fill=Y)
        
        self.POS_records.heading("Item",text="Item")
        self.POS_records.heading("Qty",text="Qty")
        self.POS_records.heading("Amount",text="Amount")

        self.POS_records['show']='headings'
        
        self.POS_records.column("Item", width=120)
        self.POS_records.column("Qty",width=100)
        self.POS_records.column("Amount",width=100)
      
        self.POS_records.pack(fill=BOTH,expand=1)
        self.POS_records.bind("<ButtonRelease-1>")

        self.txtReceipt = Text(ReceiptFrame, width=79, height=1,font=('arial', 5,'bold'))
        self.txtReceipt.pack()
        self.txtReceipt.insert(END,"Item\t\t\t\t Qty\t\t\t Amount\t\n")


        #========================================================Calculate=======================================================================
        self.btn7=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='7',command=lambda:btnClick(7),
                    bg='cadet blue').grid(row=1, column=0)
        self.btn8=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='8',command=lambda:btnClick(8),
                    bg='cadet blue').grid(row=1, column=1)
        self.btn9=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='9',command=lambda:btnClick(9),
                    bg='cadet blue').grid(row=1, column=2)
         
        #===============================================================================================================================
         
        self.btn4=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='4',command=lambda:btnClick(4),
                    bg='cadet blue').grid(row=2, column=0)
        self.btn5=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='5',command=lambda:btnClick(5),
                    bg='cadet blue').grid(row=2, column=1)
        self.btn6=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='6',command=lambda:btnClick(6),
                    bg='cadet blue').grid(row=2, column=2)         
        #===============================================================================================================================
         
        self.btn1=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='1',command=lambda:btnClick(1),
                    bg='cadet blue').grid(row=3, column=0)
        self.btn2=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='2',command=lambda:btnClick(2),
                    bg='cadet blue').grid(row=3, column=1)
        self.btn3=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='3',command=lambda:btnClick(3),
                    bg='cadet blue').grid(row=3, column=2)         
        #===============================================================================================================================
         
        self.btn0=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='0',command=lambda:btnClick(0),
                    bg='cadet blue').grid(row=4, column=0)
        self.btnDecimal=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='.',command=lambda:btnClick('.'),
                          bg='cadet blue').grid(row=4, column=1)
        self.btnClear=Button(ChangeButtonFrame,padx=13,pady=22,bd=8, fg='black',font=('arial', 20,'bold'), text='c',command=btnClearDisplay,
                        bg='cadet blue').grid(row=4, column=2)

        #==================================================ITEMS=============================================================================

        self.btnCake1=Button(FoodItemFrame, padx=2,image  = self.Cake1, width =104, height=104,bd=2,command=Cake1)                                     
        self.btnCake1.grid(row=0,column=3,padx=4,pady=2)
        
        self.btnCake2=Button(FoodItemFrame, padx=2,image  = self.Cake2, width =104, height=104,bd=2,command=Cake2)                                     
        self.btnCake2.grid(row=0,column=4,padx=2)       
      
        self.btnCake4=Button(FoodItemFrame, padx=2,image  = self.Cake4, width =104, height=104,bd=2,command=Cake4)                                     
        self.btnCake4.grid(row=0,column=5,padx=2) 

        self.btnCake3=Button(FoodItemFrame, padx=2,image  = self.Cake3, width =104, height=104,bd=2,command=Cake3)                                     
        self.btnCake3.grid(row=0,column=6,padx=2)

        self.btnCake5=Button(FoodItemFrame, padx=2,image  = self.Cake5, width =104, height=104,bd=2,command=Cake5)                                     
        self.btnCake5.grid(row=0,column=2,padx=2)

        self.btnCake6=Button(FoodItemFrame, padx=2,image  = self.Cake6, width =104, height=104,bd=2,command=Cake6)                                     
        self.btnCake6.grid(row=0,column=1,padx=2)

        #==============================================================================================
        self.btnCoffee3=Button(FoodItemFrame, padx=2,image  = self.Coffee3, width =104, height=104,bd=2,command=Coffee3)
        self.btnCoffee3.grid(row=1,column=1,padx=2)        

        self.btnCoffee4=Button(FoodItemFrame, padx=2,image  = self.Coffee4, width =104, height=104,bd=2,command=Coffee4)
        self.btnCoffee4.grid(row=1,column=2,padx=2)
        
        self.btnCoffee1=Button(FoodItemFrame, padx=2,image= self.Coffee1, width =104, height=104,bd=2,command=Coffee1)
        self.btnCoffee1.grid(row=1,column=3,padx=4,pady=2)
        
        self.btnCoffee2=Button(FoodItemFrame, padx=2,image= self.Coffee2, width =104, height=104,bd=2,command=Coffee2)
        self.btnCoffee2.grid(row=1,column=4,padx=2)
        
        self.btnCoffee6=Button(FoodItemFrame, padx=2,image  = self.Coffee6, width =104, height=104,bd=2,command=Coffee6)
        self.btnCoffee6.grid(row=1,column=5,padx=2)

        self.btnCoffee5=Button(FoodItemFrame, padx=2,image  = self.Coffee5, width =104, height=104,bd=2,command=Coffee5)
        self.btnCoffee5.grid(row=1,column=6,padx=2)
        #==============================================================================================
      
        self.btnDrink1=Button(FoodItemFrame, padx=2,image  = self.Drink1, width =104, height=104,bd=2,command=Drink1)                                     
        self.btnDrink1.grid(row=2,column=1,padx=4,pady=2)

        self.btnDrink4=Button(FoodItemFrame, padx=2,image  = self.Drink4, width =104, height=104,bd=2,command=Drink4)                                     
        self.btnDrink4.grid(row=2,column=2,padx=2)

        self.btnDrink3=Button(FoodItemFrame, padx=2,image  = self.Drink3, width =104, height=104,bd=2,command=Drink3)                                     
        self.btnDrink3.grid(row=2,column=3,padx=2)
        
        self.btnDrink6=Button(FoodItemFrame, padx=2,image  = self.Drink6, width =104, height=104,bd=2,command=Drink6)                                     
        self.btnDrink6.grid(row=2,column=4,padx=2)   

        self.btnDrink5=Button(FoodItemFrame, padx=2,image  = self.Drink5, width =104, height=104,bd=2,command=Drink5)                                     
        self.btnDrink5.grid(row=2,column=5,padx=2)

        self.btnDrink2=Button(FoodItemFrame, padx=2,image  = self.Drink2, width =104, height=104,bd=2,command=Drink2)                                     
        self.btnDrink2.grid(row=2,column=6,padx=2)       

        #==============================================================================================     
        self.btnIceCake6=Button(FoodItemFrame, padx=2,image  = self.IceCake6, width =104, height=104,bd=2,command=IceCake6)                                     
        self.btnIceCake6.grid(row=3,column=1,padx=2)

        self.btnIceCake4=Button(FoodItemFrame, padx=2,image  = self.IceCake4, width =104,height=104,bd=2,command=IceCake4)                                     
        self.btnIceCake4.grid(row=3,column=2,padx=2) 
        
        self.btnIceCake3=Button(FoodItemFrame, padx=2,image  = self.IceCake3, width =104, height=104,bd=2,command=IceCake3)                                     
        self.btnIceCake3.grid(row=3,column=3,padx=2)     
        
        self.btnIceCake2=Button(FoodItemFrame, padx=2,image  = self.IceCake2, width =104, height=104,bd=2,command=IceCake2)                                     
        self.btnIceCake2.grid(row=3,column=4,padx=2)

        self.btnIceCake5=Button(FoodItemFrame, padx=2,image  = self.IceCake5, width =104, height=104,bd=2,command=IceCake5)                                     
        self.btnIceCake5.grid(row=3,column=5,padx=2)


        self.btnIceCake1=Button(FoodItemFrame,padx=2,image = self.IceCake1,width =104, height=104,bd=2,command=IceCake1)                                     
        self.btnIceCake1.grid(row=3,column=6,padx=4,pady=4)
        #==============================================================================================

        
       
if __name__=='__main__':
    root = Tk()
    application = POS(root)
    root.mainloop()













        


        
